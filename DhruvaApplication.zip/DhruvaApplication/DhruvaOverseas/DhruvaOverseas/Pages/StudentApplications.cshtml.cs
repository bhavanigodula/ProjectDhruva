using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DhruvaOverseas.Pages
{
    public class StudentApplicationsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
