using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DhruvaOverseas.Pages.Students
{
    public class DeleteModel : PageModel
    {
       
        public class StudentInfo
            {
            public string sid;
            public string name;
            public string sname;
            public string mobile;
            public string amobile;
            public string email;
        }
        public StudentInfo studentInfo = new StudentInfo();
        public string errormessage = "";
        public string successmessage = "";
       
        public void OnGet()
        {
            string sid = Request.Query["sid"];


            try
            {
                string connectionstring = "Data Source=DESKTOP-2SPFC3N\\MYSQLSERVER;Initial Catalog=dhruva;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();
                    string sql = "delete *from student where sid=@sid";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                       
                        
                                command.ExecuteNonQuery();

                               
                            
                    }
                    connection.Close();
                    Response.Redirect("/Student");
                }
            }

            catch (Exception ex)
            {
                errormessage = ex.Message;
            }
        }
        public void OnPost()
        {
            //Console.Write("Welcome");
        }
    }
}
