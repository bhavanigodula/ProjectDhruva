using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DhruvaOverseas.Pages.Students
{
    public class PersonalModel : PageModel
    {
        public class StudentInfo
        {
            public string sid;
            public string name;
            public string sname;
            public string mobile;
            public string amobile;
            public string email;
            public string dob;
            public string gender;
            public string msatus;
            public string address1;
            public string address2;
            public string country;
            public string state;
            public string city;
            public string pincode;
            public string passportnumber;
            public string issuedate;
            public string expirydate;
            public string issuecountry;
            public string placeofbirth;
            public string countryofbirth;
           

            // public DateTime date = DateTime.Today;
        }
        public StudentInfo studentInfo = new StudentInfo();
        public string errormessage = "";
        public string successmessage = "";



        public void OnGet()
        {
            //   string sid = Request.Query["@item.sid"];
            string sid = Request.Query["sid"];


            try
            {
                string connectionstring = "Data Source=DESKTOP-2SPFC3N\\MYSQLSERVER;Initial Catalog=dhruva;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();
                    string sql = "select *from student where sid=@sid";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@sid", sid);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                StudentInfo studentInfos = new StudentInfo();
                                studentInfo.sid = reader.GetInt32(0).ToString();
                                studentInfo.name = reader.GetString(1);
                                studentInfo.sname = reader.GetString(2);
                                studentInfo.mobile = reader.GetString(3);
                                studentInfo.amobile = reader.GetString(4);
                                studentInfo.email = reader.GetString(5);
                                //tudentInfo.date = reader.GetDateTime(6);

                                // listStudents.Add(studentInfo);
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                errormessage = ex.Message;
                return;
            }

        }
        public void OnPost()
        {
            studentInfo.sid = Request.Form["sid"];
            studentInfo.dob = Request.Form["dob"];
            studentInfo.gender = Request.Form["gender"];
            studentInfo.msatus = Request.Form["mstatus"];
            studentInfo.address1 = Request.Form["address1"];
            studentInfo.address2 = Request.Form["address2"];
            studentInfo.country = Request.Form["country"];
            studentInfo.state = Request.Form["state"];
            studentInfo.city = Request.Form["city"];
            studentInfo.pincode = Request.Form["pincode"];
            studentInfo.passportnumber = Request.Form["passportnumber"];
            studentInfo.issuedate = Request.Form["issuedate"];
            studentInfo.expirydate = Request.Form["expirydate"];
            studentInfo.issuecountry = Request.Form["issuecountry"];
            studentInfo.placeofbirth = Request.Form["placeofbirth"];
            studentInfo.countryofbirth = Request.Form["countryofbirth"];
            

            if (studentInfo.dob.Length == 0 || studentInfo.gender.Length == 0 ||
               studentInfo.msatus.Length == 0 || studentInfo.address1.Length == 0 ||
               studentInfo.address2.Length == 0 || studentInfo.country.Length == 0 || studentInfo.state.Length == 0 ||
               studentInfo.city.Length == 0 || studentInfo.pincode.Length == 0 ||
               studentInfo.passportnumber.Length == 0 || studentInfo.issuedate.Length == 0 || studentInfo.expirydate.Length == 0 ||
               studentInfo.issuecountry.Length == 0 || studentInfo.placeofbirth.Length == 0 ||
               studentInfo.countryofbirth.Length == 0)
            {
                errormessage = "Enter All the Fields";
                return;
            }

            try
            {
                string connectionstring = "Data Source=DESKTOP-2SPFC3N\\MYSQLSERVER;Initial Catalog=dhruva;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();



                    string sql = "insert into profile" +
                        "(dob,gender,msatus,address1,address2,country,state,city,pin,passportnumber,passportissuedate,passportexpirydate,pissuedcountry,placeofbirth,countryofbirth,sid) values" +
                       " (@dob,@gender,@msatus,@address1,@address2,@country,@state,@city,@pincode,@passportnumber," +
                       "@passportissuedate,@passportexpirydate,@pissuedcountry,@placeofbirth,@countryofbirth,@sid); ";


                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {

                        //command.Parameters.AddWithValue("@sid", studentInfo.sid);
                        command.Parameters.AddWithValue("@dob", studentInfo.dob);
                        command.Parameters.AddWithValue("@gender", studentInfo.gender);
                        command.Parameters.AddWithValue("@msatus", studentInfo.msatus);
                        command.Parameters.AddWithValue("@address1", studentInfo.address1);
                        command.Parameters.AddWithValue("@address2", studentInfo.address2);
                        command.Parameters.AddWithValue("@country", studentInfo.country);
                        command.Parameters.AddWithValue("@state", studentInfo.state);
                        command.Parameters.AddWithValue("@city", studentInfo.city);
                        command.Parameters.AddWithValue("@pincode", studentInfo.pincode);
                        command.Parameters.AddWithValue("@passportnumber", studentInfo.passportnumber);
                        command.Parameters.AddWithValue("@passportissuedate", studentInfo.issuedate);
                        command.Parameters.AddWithValue("@passportexpirydate", studentInfo.expirydate);
                        command.Parameters.AddWithValue("@pissuedcountry", studentInfo.issuecountry);
                        command.Parameters.AddWithValue("@placeofbirth", studentInfo.placeofbirth);
                        command.Parameters.AddWithValue("@countryofbirth", studentInfo.countryofbirth);
                        command.Parameters.AddWithValue("@sid", studentInfo.sid);
                        // command.Parameters.AddWithValue("@date", studentInfo.date);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errormessage = ex.Message;
                return;
            }



            successmessage = "Student Details Registered Successfully";
            Response.Redirect("./Academic");
            //esponse.Redirect("Index");
        }


    }


}
