using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DhruvaOverseas.Pages.Students
{
    public class WorkModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
