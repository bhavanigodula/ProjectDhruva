using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace DhruvaOverseas.Pages
{
    public class registerModel : PageModel
    {
      //public List<StudentInfo> listStudents = new List<StudentInfo>();

        public StudentInfo studentInfo = new StudentInfo();
        public string errormessage = "";
        public string successmessage = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {
            studentInfo.name = Request.Form["name"];
            studentInfo.sname = Request.Form["sname"];
            studentInfo.mobile = Request.Form["mobile"];
            studentInfo.amobile = Request.Form["amobile"];
            studentInfo.email = Request.Form["email"];

            if (studentInfo.name.Length == 0 || studentInfo.sname.Length == 0 ||
                studentInfo.mobile.Length == 0 || studentInfo.amobile.Length == 0 ||
                studentInfo.email.Length == 0)
            {
                errormessage = "Enter All the Fields";
                return;
            }
            // Save the student data into database

            try
            {
                string connectionstring = "Data Source=DESKTOP-2SPFC3N\\MYSQLSERVER;Initial Catalog=dhruva;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    connection.Open();



                    string sql = "insert into student" +
                        "(name,sname,mobile,amobile,email) values" +
                       " (@name,@sname,@mobile,@amobile,@email); ";


                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {

                        //command.Parameters.AddWithValue("@sid", studentInfo.sid);
                        command.Parameters.AddWithValue("@name", studentInfo.name);
                        command.Parameters.AddWithValue("@sname", studentInfo.sname);
                        command.Parameters.AddWithValue("@mobile", studentInfo.mobile);
                        command.Parameters.AddWithValue("@amobile", studentInfo.amobile);
                        command.Parameters.AddWithValue("@email", studentInfo.email);
                        // command.Parameters.AddWithValue("@date", studentInfo.date);

                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                errormessage = ex.Message;
                return;
            }

            studentInfo.name = "";
            studentInfo.sname = "";
            studentInfo.mobile = "";
            studentInfo.amobile = "";
            studentInfo.email = "";

            //successmessage = "Student Details Registered Successfully";
          //  Response.Redirect("/Student");
            //esponse.Redirect("Index");
        }
        
        public class StudentInfo
        {
          //public int sid;
            public string name;
            public string sname;
            public string mobile;
            public string amobile;
            public string email;
         // public DateTime date = DateTime.Today;


        }
    }
}
